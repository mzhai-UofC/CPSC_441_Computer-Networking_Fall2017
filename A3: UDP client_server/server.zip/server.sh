java -Djava.util.logging.config.file=logging.properties -jar ffserver.jar 2225 10 0.1
